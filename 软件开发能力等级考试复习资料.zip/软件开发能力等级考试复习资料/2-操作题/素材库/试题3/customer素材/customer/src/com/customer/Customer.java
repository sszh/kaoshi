package com.customer;

public class Customer {
	
}
