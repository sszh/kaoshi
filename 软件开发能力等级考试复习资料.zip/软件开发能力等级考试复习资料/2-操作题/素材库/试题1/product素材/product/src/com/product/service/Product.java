package com.product.service;

public class Product {

	//...
}
