package com.product.controller;

public class IdCommand {

	//...
}
